# BrioLab 3D — Calculadora 2.0

Proyecto Android nuevo, independiente de la calculadora anterior.

- Calculadora de costos para impresión 3D.
- Base de productos.
- Alta de producto mediante ventana propia.
- Miniatura de foto junto al producto.
- Edición y eliminación.
- Búsqueda por número.
- Guardado automático en el dispositivo.
- Exportación e importación de respaldo.
- Logo BrioLab 3D como icono y dentro de la app.
- Funciona sin conexión.
