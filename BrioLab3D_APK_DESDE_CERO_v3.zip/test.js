
(function(){
'use strict';
const KEY='briolab3d_v3';
const defaults={filamento:25000,kwh:174.60,watts:130,maquina:1650000,vida:5000,desperdicio:5,mano:0,pack:0,comision:0,markup:100};
let state={settings:{...defaults},products:[],expanded:true,collapsed:{config:false,calc:false,products:false,data:false}};
const $=id=>document.getElementById(id);
function num(v,d=0){const n=Number(v);return Number.isFinite(n)?Math.max(0,n):d}
function money(v){return '$ '+Math.round(Number.isFinite(v)?v:0).toLocaleString('es-AR')}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){};showStatus('Guardado automáticamente.')}
function showStatus(t){$('status').textContent=t;clearTimeout(showStatus.t);showStatus.t=setTimeout(()=>$('status').textContent='',1800)}
function load(){try{const x=JSON.parse(localStorage.getItem(KEY)||'null');if(x){state={settings:{...defaults,...x.settings},products:Array.isArray(x.products)?x.products:[],expanded:x.expanded!==false,collapsed:{config:false,calc:false,products:false,data:false,...(x.collapsed||{})}}}}catch(e){state={settings:{...defaults},products:[],expanded:true}}}
function bindSettings(){
  Object.keys(defaults).forEach(k=>{
    const el=$(k); el.value=state.settings[k];
    el.oninput=()=>{state.settings[k]=num(el.value);calculate();save()}
  })
}
function calculateFor(grams,hours){
  const s=state.settings,g=num(grams),h=num(hours);
  const fil=g/1000*s.filamento;
  const ele=s.watts/1000*h*s.kwh;
  const amo=s.vida?s.maquina/s.vida*h:0;
  const mp=s.mano+s.pack;
  const base=fil+ele+amo+mp;
  const waste=base*s.desperdicio/100;
  const cost=base+waste;
  const comm=Math.min(99.99,s.comision)/100;
  const min=cost/(1-comm);
  const sale=cost*(1+s.markup/100)/(1-comm);
  const profit=sale*(1-comm)-cost;
  return {fil,ele,amo,mp,waste,cost,min,sale,profit}
}
function calculate(){
  const r=calculateFor($('calcGramos').value,$('calcHoras').value);
  [['rFilamento',r.fil],['rElectricidad',r.ele],['rAmortizacion',r.amo],['rManoPack',r.mp],['rDesperdicio',r.waste],['rCosto',r.cost],['rMinimo',r.min],['rGanancia',r.profit]].forEach(([id,v])=>$(id).textContent=money(v));
  $('precioVenta').textContent=money(r.sale)
}
function nextNum(){return state.products.reduce((m,p)=>Math.max(m,num(p.number)),0)+1}
function renderSections(){
  const map={config:'configCard',calc:'calcCard',products:'productsCard',data:'dataCard'};
  Object.entries(map).forEach(([key,id])=>{const card=$(id),btn=$(key+'Toggle');if(!card||!btn)return;const collapsed=!!state.collapsed?.[key];card.classList.toggle('collapsed',collapsed);btn.textContent=collapsed?'＋':'−';btn.setAttribute('aria-label',collapsed?'Mostrar sección':'Ocultar sección')});
}
function toggleSection(key){state.collapsed=state.collapsed||{};state.collapsed[key]=!state.collapsed[key];renderSections();save()}
function render(){
  renderSections();
  const list=$('productList');
  $('count').textContent=state.products.length+' producto'+(state.products.length===1?'':'s')+' guardado'+(state.products.length===1?'':'s');
  list.style.display=state.expanded?'block':'none';
  if(!state.products.length){list.innerHTML='<div class="empty">No hay productos todavía. Tocá ＋ Producto para agregar el primero.</div>';return}
  list.innerHTML='';
  state.products.forEach((p,i)=>{
    const row=document.createElement('div');row.className='product-row';
    const wrapField=(cls,label,input)=>{const w=document.createElement('div');w.className='product-field '+cls;const lab=document.createElement('span');lab.className='field-label';lab.textContent=label;w.append(lab,input);return w};
    const n=document.createElement('input');n.type='number';n.min='1';n.value=p.number??'';n.title='Número de producto';
    const name=document.createElement('input');name.type='text';name.maxLength=80;name.value=p.name||'';name.title='Descripción';
    const g=document.createElement('input');g.type='number';g.min='0';g.step='0.1';g.value=p.grams??'';g.title='Gramos';
    const h=document.createElement('input');h.type='number';h.min='0';h.step='0.1';h.value=p.hours??'';h.title='Horas de impresión';
    const nF=wrapField('pf-num','N.º de producto',n), nameF=wrapField('pf-name','Descripción',name), gF=wrapField('pf-grams','Gramos',g), hF=wrapField('pf-hours','Horas de impresión',h);
    const photo=document.createElement('label');photo.className='photo';photo.title=p.photo?'Cambiar foto':'Agregar foto';
    const file=document.createElement('input');file.type='file';file.accept='image/*';
    if(p.photo){
      const img=document.createElement('img');img.src=p.photo;img.alt='Foto de '+(p.name||'producto');photo.appendChild(img);
    }else{
      const cam=document.createElement('span');cam.className='camera';cam.textContent='📷';photo.appendChild(cam);
    }
    photo.appendChild(file);
    const del=document.createElement('button');del.type='button';del.className='delete';del.textContent='×';del.title='Eliminar';
    n.addEventListener('change',()=>{p.number=Math.max(1,Math.round(num(n.value,1)));render();save()});
    name.addEventListener('change',()=>{p.name=name.value;render();save()});
    g.addEventListener('change',()=>{p.grams=num(g.value);calculate();save()});
    h.addEventListener('change',()=>{p.hours=num(h.value);calculate();save()});
    file.addEventListener('change',async e=>{
      const f=e.target.files&&e.target.files[0];if(!f)return;
      try{p.photo=await resizeImage(f);render();save()}catch(err){showStatus('No se pudo cargar la foto.')}
    });
    del.addEventListener('click',()=>{
      if(confirm('¿Eliminar este producto?')){state.products.splice(i,1);render();save()}
    });
    row.append(nF,nameF,gF,hF,photo,del);list.appendChild(row);
  })
}
function resizeImage(file){
  return new Promise((resolve,reject)=>{
    const r=new FileReader();
    r.onload=()=>{
      const img=new Image();
      img.onload=()=>{
        const max=700,scale=Math.min(1,max/Math.max(img.width,img.height));
        const c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));
        const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);
        resolve(c.toDataURL('image/jpeg',.78))
      };
      img.onerror=reject;img.src=r.result
    };
    r.onerror=reject;r.readAsDataURL(file)
  })
}
function openModal(){
  $('pNum').value=nextNum();$('pName').value='';$('pGrams').value='';$('pHours').value='';$('pPhoto').value='';
  $('preview').innerHTML='<span class="camera">📷</span>';delete $('preview').dataset.photo;
  $('modalStatus').textContent='';$('modal').classList.add('open')
}
function closeModal(){$('modal').classList.remove('open')}
function openDetail(p){
  const r=calculateFor(p.grams,p.hours);
  $('detailContent').innerHTML='';
  const head=document.createElement('div');head.className='detail-head';
  const ph=document.createElement('div');ph.className='detail-photo';
  if(p.photo){const img=document.createElement('img');img.src=p.photo;img.alt='Foto de '+p.name;ph.appendChild(img)}
  else {const cam=document.createElement('span');cam.className='camera';cam.textContent='📷';ph.appendChild(cam)}
  const info=document.createElement('div');
  info.innerHTML='<div class="detail-title"></div><div class="detail-meta"></div>';
  info.querySelector('.detail-title').textContent=p.name||'Sin nombre';
  info.querySelector('.detail-meta').textContent='Nº '+p.number+' · '+num(p.grams)+' g · '+num(p.hours)+' h';
  head.append(ph,info);
  const result=document.createElement('div');result.className='detail-result';
  result.innerHTML='<div class="detail-sale">PRECIO DE VENTA<strong>'+money(r.sale)+'</strong></div><div class="detail-grid"></div>';
  const grid=result.querySelector('.detail-grid');
  [['Filamento',r.fil],['Electricidad',r.ele],['Amortización A1',r.amo],['Mano de obra + packaging',r.mp],['Desperdicio / fallas',r.waste],['Costo real',r.cost],['Precio mínimo',r.min],['Ganancia por unidad',r.profit]].forEach(([label,val])=>{
    const row=document.createElement('div');row.className='row';row.innerHTML='<span>'+label+'</span><b>'+money(val)+'</b>';grid.appendChild(row)
  });
  $('detailContent').append(head,result);$('detailModal').classList.add('open')
}
function closeDetail(){$('detailModal').classList.remove('open')}
function searchProduct(){
  const n=Math.round(num($('searchProduct').value));
  if(!n){$('searchStatus').textContent='Escribí un número de producto.';return}
  const p=state.products.find(x=>Math.round(num(x.number))===n);
  if(!p){$('searchStatus').textContent='No encontré el producto Nº '+n+'.';return}
  $('searchStatus').textContent='Producto Nº '+n+' encontrado.';
  openDetail(p)
}
$('configToggle').addEventListener('click',()=>toggleSection('config'));$('calcToggle').addEventListener('click',()=>toggleSection('calc'));$('productsToggle').addEventListener('click',()=>toggleSection('products'));$('dataToggle').addEventListener('click',()=>toggleSection('data'));
$('addProduct').addEventListener('click',openModal);
$('closeModal').addEventListener('click',closeModal);
$('cancelModal').addEventListener('click',closeModal);
$('choosePhoto').addEventListener('click',()=>$('pPhoto').click());
$('pPhoto').addEventListener('change',async e=>{
  const f=e.target.files&&e.target.files[0];if(!f)return;
  try{const data=await resizeImage(f);$('preview').innerHTML='';const img=document.createElement('img');img.src=data;img.alt='Vista previa';$('preview').appendChild(img);$('preview').dataset.photo=data}
  catch(err){$('modalStatus').textContent='No se pudo cargar la foto.'}
});
$('saveProduct').addEventListener('click',()=>{
  const name=$('pName').value.trim();
  if(!name){$('modalStatus').textContent='Escribí el nombre del producto.';return}
  const requested=Math.max(1,Math.round(num($('pNum').value,nextNum())));
  if(state.products.some(p=>Math.round(num(p.number))===requested)){ $('modalStatus').textContent='Ese número de producto ya existe.';return}
  state.products.push({number:requested,name,grams:num($('pGrams').value),hours:num($('pHours').value),photo:$('preview').dataset.photo||''});
  closeModal();render();save()
});
$('collapseProducts').addEventListener('click',()=>{state.expanded=false;render();save()});
$('expandProducts').addEventListener('click',()=>{state.expanded=true;render();save()});
$('searchBtn').addEventListener('click',searchProduct);
$('searchProduct').addEventListener('keydown',e=>{if(e.key==='Enter')searchProduct()});
$('calcGramos').addEventListener('input',calculate);
$('calcHoras').addEventListener('input',calculate);
$('closeDetail').addEventListener('click',closeDetail);
$('closeDetailBtn').addEventListener('click',closeDetail);
$('detailModal').addEventListener('click',e=>{if(e.target===$('detailModal'))closeDetail()});
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});
$('exportBtn').addEventListener('click',()=>{
  const blob=new Blob([JSON.stringify(state)],{type:'application/json'}),a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='BrioLab3D_respaldo.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)
});
$('importBtn').addEventListener('click',()=>$('backupFile').click());
$('backupFile').addEventListener('change',e=>{
  const f=e.target.files&&e.target.files[0];if(!f)return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const x=JSON.parse(r.result);
      state={settings:{...defaults,...x.settings},products:Array.isArray(x.products)?x.products:[],expanded:x.expanded!==false,collapsed:{config:false,calc:false,products:false,data:false,...(x.collapsed||{})}};
      bindSettings();render();calculate();save();showStatus('Respaldo importado.')
    }catch(err){showStatus('Respaldo inválido.')}
  };
  r.readAsText(f)
});
$('resetBtn').addEventListener('click',()=>{
  if(confirm('¿Restaurar valores y borrar productos guardados?')){state={settings:{...defaults},products:[],expanded:true,collapsed:{config:false,calc:false,products:false,data:false}};bindSettings();render();calculate();save()}
});
load();bindSettings();render();calculate();
})();
