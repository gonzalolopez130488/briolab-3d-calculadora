# BrioLab 3D — Calculadora 3.0
Proyecto Android reconstruido desde cero.

Incluye base de productos con alta, edición, eliminación, fotos con miniatura, guardado automático y controles ▲/▼ para ocultar o desplegar el listado completo.
