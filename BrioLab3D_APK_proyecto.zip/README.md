# BrioLab 3D — APK
Aplicación Android nativa con una interfaz WebView local. Incluye:
- Calculadora de costos y precio de venta.
- Base de productos ilimitada.
- Foto por producto con miniatura inmediata y reemplazo.
- Guardado automático en el teléfono.
- Buscador por número de publicación.
- Respaldo e importación JSON.
- Logo BrioLab 3D en la pantalla y como icono.
- Funciona sin Internet.

Para compilar: abrir esta carpeta en Android Studio y Build > Build APK(s).
